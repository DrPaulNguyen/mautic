<?php return array (
  0 => 'Mautic\\Middleware\\CORSMiddleware',
  1 => 'Mautic\\Middleware\\CatchExceptionMiddleware',
  2 => 'Mautic\\Middleware\\VersionCheckMiddleware',
  3 => 'Mautic\\Middleware\\TrustMiddleware',
);